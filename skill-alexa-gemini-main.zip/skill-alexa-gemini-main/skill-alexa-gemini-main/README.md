# Modelo de Skill Alexa para integrar o **Gemini da Google**  
Use o **Gemini Pro** na Alexa 😊  

## Instruções  
- Crie uma conta e uma chave de autenticação de API no Google AI Studio:  
  👉 https://aistudio.google.com/app/apikey  

- Coloque crédito para poder usar a API:  
  👉 https://ai.google.dev/pricing  

> ⚠️ IMPORTANTE: a API e o Bard são coisas diferentes.  
> A API do Gemini é independente e é cobrada por uso.  

A API é paga por uso, ou seja, por cada pergunta e resposta é cobrado alguns centavos ([veja aqui](https://ai.google.dev/pricing)). O valor varia de acordo com o modelo selecionado.  

---

## Criar a Skill  
- Vá em: https://developer.amazon.com/alexa/console/ask/create-new-skill  
  - **Name your Skill**: Escolha um nome (Ex: Gemini Chat)  
  - **Choose a primary locale**: Portuguese (BR)  
  - **Em tipo de experiência selecione**: Other > Custom > Alexa-hosted (Python)  
  - **Hosting region**: pode deixar o padrão (US East (N. Virginia))  
  - **Templates**: clique em Import Skill  
  - Insira o endereço:  
    ```
    https://github.com/alexandremendoncaalvaro/skill-alexa-gemini.git
    ```

---

## Configuração do Código  
- Vá na aba **Code**  
- Insira sua chave no arquivo `lambda/lambda_function.py`:  
  ```python
  import google.generativeai as genai

  genai.configure(api_key="substitua-por-sua-api-key-do-gemini")
