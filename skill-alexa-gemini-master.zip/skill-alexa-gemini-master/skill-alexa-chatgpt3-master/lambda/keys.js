// Você precisará obter sua própria API KEY do Google Gemini (Google AI Studio).
// Veja em: https://makersuite.google.com/ ou https://ai.google.dev/

module.exports.GEMINI_API_KEY = 'SUBSTITUA_POR_SUA_GEMINI_API_KEY';
